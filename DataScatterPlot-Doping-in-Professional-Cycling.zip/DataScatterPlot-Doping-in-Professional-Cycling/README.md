# Doping in Professional Cycling - Interactive Scatterplot

## Overview
This project presents a high-performance, interactive data visualization showcasing the 35 fastest climbing times up the legendary Alpe d'Huez. Built with **D3.js**, this scatterplot provides a deep dive into the intersection of athletic performance and the history of doping allegations in professional bicycle racing. It transforms a static dataset into a compelling narrative using modern web technologies and sophisticated design principles.

## Features
- **Dynamic Visualization**: Implements a time-based Y-axis and linear X-axis (Year) using D3 scales to accurately map race performance.
- **Glassmorphism UI**: A cutting-edge "Dark Glass" aesthetic featuring blurred backgrounds, vibrant gradients, and metallic typography for a premium feel.
- **D3 Animations**: Data points feature a staggered "bloom" entrance animation upon loading, creating an engaging user experience.
- **Interactive Tooltips**: High-precision hover states that reveal context-aware data using glass-morphism styling.
- **Cyclist Info Panel**: A slide-out detail panel that provides a comprehensive look at each athlete, including their nationality, rank, and detailed doping allegations with external documentation links.

## Technical Architecture
The application is built using a **Pure Frontend** approach, ensuring rapid load times and seamless interactions without the overhead of heavy frameworks. 
- **D3.js v5**: Utilized for robust data binding and SVG manipulation.
- **CSS3 Custom Properties**: Centralized theme management for consistent colors and spacing.
- **Responsive Layout**: Designed to adapt to various screen sizes while maintaining the integrity of the visualization.

## How to Use
1. **Explore**: Hover over any data point (dot) to see a quick summary of the rider and their time.
2. **Analyze**: Click on a specific dot to open the side information panel for in-depth details.
3. **Filter**: Use the color-coded legend to distinguish between clean performances and those with doping allegations.

This project demonstrates the power of data storytelling through custom visualization and modern UI design.
