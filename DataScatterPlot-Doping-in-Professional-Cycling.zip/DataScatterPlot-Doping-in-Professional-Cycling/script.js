let url = 'https://raw.githubusercontent.com/freeCodeCamp/ProjectReferenceData/master/cyclist-data.json'
let req = new XMLHttpRequest()

let values = []

let xScale
let yScale

let xAxis
let yAxis

let width = 800
let height = 500
let padding = 60

let svg = d3.select('#canvas')
let tooltip = d3.select('#tooltip')
let infoPanel = d3.select('#info-panel')

let closePanel = () => {
    infoPanel.classed('open', false)
    d3.selectAll('.dot').classed('active', false)
}

let generateScales = () => {
    xScale = d3.scaleLinear()
        .domain([d3.min(values, (item) => item['Year']) - 1, d3.max(values, (item) => item['Year']) + 1])
        .range([padding, width - padding])

    yScale = d3.scaleTime()
        .domain([d3.min(values, (item) => new Date(item['Seconds'] * 1000)), d3.max(values, (item) => new Date(item['Seconds'] * 1000))])
        .range([padding, height - padding])
}

let drawCanvas = () => {
    svg.attr('width', width)
    svg.attr('height', height)
}

let drawPoints = () => {
    svg.selectAll('circle')
        .data(values)
        .enter()
        .append('circle')
        .attr('class', 'dot')
        .attr('r', 0) // Start with 0 radius for animation
        .attr('data-xvalue', (item) => item['Year'])
        .attr('data-yvalue', (item) => new Date(item['Seconds'] * 1000))
        .attr('cx', (item) => xScale(item['Year']))
        .attr('cy', (item) => yScale(new Date(item['Seconds'] * 1000)))
        .attr('fill', (item) => item['Doping'] === "" ? '#10b981' : '#f43f5e')
        .on('mouseover', (item) => {
            tooltip.transition()
                .duration(200)
                .style('opacity', 1)
                .style('visibility', 'visible')
            
            tooltip.html(`
                <strong>${item['Name']}: ${item['Nationality']}</strong>
                Year: ${item['Year']}, Time: ${item['Time']}
                ${item['Doping'] ? '<br/><br/>' + item['Doping'] : ''}
            `)
                .style('left', (d3.event.pageX + 15) + 'px')
                .style('top', (d3.event.pageY - 28) + 'px')
            
            tooltip.attr('data-year', item['Year'])
        })
        .on('mouseout', () => {
            tooltip.transition()
                .duration(200)
                .style('opacity', 0)
                .style('visibility', 'hidden')
        })
        .on('click', function(item) {
            d3.selectAll('.dot').classed('active', false)
            d3.select(this).classed('active', true)
            
            infoPanel.classed('open', true)
            
            d3.select('#panel-content').html(`
                <h2>${item['Name']}</h2>
                <div class="info-detail">
                    <div class="info-label">Nationality</div>
                    <div class="info-value">${item['Nationality']}</div>
                </div>
                <div class="info-detail">
                    <div class="info-label">Year</div>
                    <div class="info-value">${item['Year']}</div>
                </div>
                <div class="info-detail">
                    <div class="info-label">Time</div>
                    <div class="info-value">${item['Time']}</div>
                </div>
                <div class="info-detail">
                    <div class="info-label">Rank</div>
                    <div class="info-value">#${item['Rank']}</div>
                </div>
                ${item['Doping'] ? `
                    <div class="doping-allegation">
                        <strong>Allegation:</strong><br/>
                        ${item['Doping']}
                    </div>
                ` : '<div class="info-value" style="color: #10b981; margin-top: 20px;">No doping allegations</div>'}
                ${item['URL'] ? `<p><a href="${item['URL']}" target="_blank" style="color: #8b5cf6; text-decoration: none; font-weight: 600;">Read More &rarr;</a></p>` : ''}
            `)
            
            d3.event.stopPropagation()
        })
        .transition() // Animate point entrance
        .duration(800)
        .delay((d, i) => i * 20)
        .attr('r', 7)

    d3.select('body').on('click', () => {
        closePanel()
    })
    
    infoPanel.on('click', () => {
        d3.event.stopPropagation()
    })
}

let generateAxes = () => {
    xAxis = d3.axisBottom(xScale)
        .tickFormat(d3.format('d'))
        .tickSizeOuter(0)

    yAxis = d3.axisLeft(yScale)
        .tickFormat(d3.timeFormat('%M:%S'))
        .tickSizeOuter(0)

    svg.append('g')
        .call(xAxis)
        .attr('id', 'x-axis')
        .attr('transform', 'translate(0, ' + (height - padding) + ')')

    svg.append('g')
        .call(yAxis)
        .attr('id', 'y-axis')
        .attr('transform', 'translate(' + padding + ', 0)')
        
    // Axis labels
    svg.append('text')
        .attr('transform', 'rotate(-90)')
        .attr('x', -height/2)
        .attr('y', 20)
        .style('text-anchor', 'middle')
        .style('font-size', '14px')
        .style('fill', '#64748b')
        .text('Time (Minutes)')

    svg.append('text')
        .attr('x', width/2)
        .attr('y', height - 10)
        .style('text-anchor', 'middle')
        .style('font-size', '14px')
        .style('fill', '#64748b')
        .text('Year')
}

req.open('GET', url, true)
req.onload = () => {
    values = JSON.parse(req.responseText)
    drawCanvas()
    generateScales()
    drawPoints()
    generateAxes()
}
req.send()